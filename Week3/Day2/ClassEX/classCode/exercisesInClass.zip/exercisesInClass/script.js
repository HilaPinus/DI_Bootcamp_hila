// retrieve the buttons
const buttonOne = document.getElementById("red");
const buttonTwo = document.getElementById("blue");

// buttonOne.addEventListener("click", changeBgBlue)
// buttonTwo.addEventListener("click", changeBgRed)

// function changeBgBlue(){
//     document.body.style.backgroundColor = "blue";
// }

// function changeBgRed(){
//     document.body.style.backgroundColor = "red";
// }

buttonOne.addEventListener("click", changeBg)
buttonTwo.addEventListener("click", changeBg)

function changeBg(event){
    console.log(event);
    console.log(event.target.id);
    document.body.style.backgroundColor = event.target.id;
}

const colors = ["blue", "yellow", "green", "pink"];

function addButtons(){
    const divContainer = document.querySelector("#container")
    for(let i=0; i<colors.length; i++){
        const btn = document.createElement("button");
        btn.textContent = colors[i];
        btn.setAttribute("id", colors[i])
        btn.addEventListener("click",changeBg);
        divContainer.appendChild(btn)
    }
}

addButtons()


