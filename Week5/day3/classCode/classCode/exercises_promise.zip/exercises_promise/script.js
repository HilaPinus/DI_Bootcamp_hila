// EXERCISE 1
// Create a function that takes in a single parameter and returns a new promise.
// Using setTimeout, after 5000 milliseconds, the promise will either resolve or reject.
// If the parameter is a string, the promise resolves with that same string uppercased.
// If the parameter is anything but a string it rejects with that same input.
// Use then to repeat the string twice use catch to console.log the error finally call a function that console.log ("congratulation")


function checkString(word){
    const mypromise = new Promise((resolve, reject) => {
        setTimeout(() => {
            if(typeof word === "string"){
                resolve(word.toUpperCase())
            } else {
                reject("WRONG PARAMETER")
            }
        }, 2000)
    })
    return mypromise;
}

//consuming the promise 

//here the promise is resolved after 2 sec, so we go straight to the then
checkString("hello")
.then((result) => console.log("IN THE THEN" ,result.repeat(2))) //HELLOHELLO
.catch((err) => console.log("IN THE CATCH", err))
.finally(() => console.log("test"))

//here the promise is rejected after 2 sec, so we go straight to the catch
checkString(1234)
.then((result) => console.log("IN THE THEN" , result.repeat(2))) 
.catch((err) => console.log("IN THE CATCH", err)) //"WRONG PARAMETER")
.finally(() => console.log("test"))

//finally method is called no matter what