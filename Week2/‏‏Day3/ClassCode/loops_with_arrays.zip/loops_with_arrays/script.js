const animals = ["dog", "cat","rabbit"];

//display each animal - without a loop
console.log(animals[0]);
console.log(animals[1]);
console.log(animals[2]);

//display each animal - with a loop
for (let counter=0; counter <=2; counter++) {
    console.log(animals[counter])
}

// 1st loop
// counter = 0

// 2nd loop
// counter = 1

// 3dr loop
// counter = 2

// USE THE LENGTH

// const animals = ["dog", "cat","rabbit"];
// --> 3 animals -- run loop 3 times
// --> 4 animals -- run loop 4 times
// index <= animals-1

const animalsFarm = ["dog", "cat","rabbit"];

// same 0 to 2
for (let index=0; index <= animalsFarm.length-1 ;index++){
    console.log(animalsFarm[index])
}

//same 0 to 2 (3 not included)
for (let index=0; index < animalsFarm.length ;index++){
    console.log(animalsFarm[index])
}

//  BEHIND THE SCENES
// animalsFarm.length = 3

// 1st loop
// index=0
// 0 <= 2 - true
// animalsFarms[index] - animalsFarms[0] -- dog

// 2nd loop
// index=1
// 1 <= 2 - true
// animalsFarms[index] - animalsFarms[1] -- cat

// 3rd loop
// index=2
// 2 <= 2 - true
// animalsFarms[index] - animalsFarms[2] -- rabbit

// SUM and PRICES
// WITHOUT A LOOP

const prices = [25, 27, 40];
let total = 0;

// total = 0, and I want to add to the total the nb 25
total = total + prices[0];
total += prices[0]; // total = 25

// total = 25, and I want to add to the total the nb 27
total += prices[1] // total = 25+27

// total = 52, and I want to add to the total the nb 40
total += prices[2] // total =  25+27+40




// WITH LOOPS


const pricesRestaurant = [25, 27, 40];
let totalSum = 0;

for (let index = 0; index < pricesRestaurant.length; index++){
    totalSum += pricesRestaurant[index];
}

console.log("totalSum is ", totalSum)