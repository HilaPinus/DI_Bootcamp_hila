// USE OF A FOR LOOP
// for - counter, index
// - do the same action several times
// - and to loop through arrays

const animals = ["dog", "cat","rabbit"];

for (let index=0; index < animals.length ;index++){
    console.log(animals[index])
}

// FOR OF WITH ARRAYS 
for (let pet of animals){
    console.log(pet)
}

// BEHIND THE SCENES
// // 1st loop
// // pet = animals[0] = "dog"

// // 2nd loop
// // pet = animals[1] = "cat"

// // 3rd loop
// // pet = animals[2] = "rabbit"

// ---------
// FOR IN - Object
// ---------

const family = {
    lastname: "Smith",
    members: 4,
    pet: true,
}

// WITHOUT A LOOP
console.log(family["lastname"]);
console.log(family["members"]);
console.log(`${family["members"]} ${family["lastname"]}`);



for (let key in family){
    console.log(key)
    // console.log(family.key) // DOT NOTATION DOESNT RECOGNIZE VARIABLES  - WRONG
    console.log(family[key]);
    console.log(`The ${key} is ${family[key]}`);
}

// // 1st loop
// // key = lastname
// // family[key] - family['lastname'] - "Smith"

// // 2nd loop
// // key = members
// // family[key] - family['members'] - 4

// ----------
// BREAK AND CONTINUE

const animalsShelter = ["dog", "cat","rabbit", "rat", "hamster"];

// STOP THE LOOP AS SOON AS WE REACH  "rabbit"
for (let pet of animalsShelter){
    if(pet === "rabbit"){
        break; //stop the loop
    } else {
        console.log(pet);
    }
}


// CONTINUE THE LOOP OF THE ANIMAL IS NOT "rabbit"
for (let pet of animalsShelter){
    if(pet !== "rabbit"){
        continue; //skip
    } else {
        console.log(pet);
    }
}