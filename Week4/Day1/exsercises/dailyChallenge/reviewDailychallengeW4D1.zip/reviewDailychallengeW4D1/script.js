const gameInfo = [
    {
      username: "john",
      team: "red",
      score: 5,
      items: ["ball", "book", "pen"]
    },
    {
      username: "becky",
      team: "blue",
      score: 10,
      items: ["tape", "backpack", "pen"]
    },
    {
      username: "susy",
      team: "red",
      score: 55,
      items: ["ball", "eraser", "pen"]
    },
    {
      username: "tyson",
      team: "green",
      score: 1,
      items: ["book", "pen"]
    },
];

const newArr = [];

//1. 
gameInfo.forEach((user) => {
    const nameOfUser = user.username + "!";
    newArr.push(nameOfUser)
})

//2
const bestUsers = [];

gameInfo.forEach((user) => {
    if(user.score > 5) {
        bestUsers.push(user.username)
    }
})

//3
let total = 0;

// gameInfo.forEach((user) => {
//     total += user.score
// })

//One line
gameInfo.forEach((user) => total += user.score)



// Array.forEach(function (element, index, array){
//     //element of the loop
//     //index of the eleemnt

// })

// Array.forEach(() => {
    
// })

// const colors = ["blue", "yellow", "red"];

// for(let i = 0; i<colors.length; i++){
//     getColor(colors[i])
//     //log
// }

// function getColor (color) {
//     console.log(color);
// }


//function declaration
function makeChocolate(gramCacao, gramSugar){
    const totalGram = gramCacao + gramSugar;
    return totalGram;
}

makeChocolate(100, 10);

//arrow function
const makeChocolate = (gramCacao, gramSugar) => {
    const totalGram = gramCacao + gramSugar;
    return totalGram;
}

makeChocolate(100, 10);

//arrow function one line
const makeChocolate = (gramCacao, gramSugar) => gramCacao + gramSugar;

makeChocolate(100, 10);