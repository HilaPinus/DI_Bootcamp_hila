// Exercise 1

// Part I
// Create a TV class with 3 parameters : brand, channel and volume Channel should be 1 by default. Volume should be 50 by default.
// Create attributes brandTV, channelTV and volumeTV equal to the 3 parameters value.
// Add methods to increase and decrease volume. When the methods are called it will increase or decrease the volume by 1.
// Create an object for the LG TV
// Call the inscrease method, and check if the volume changed


class Tv {
    constructor(brand, channel=1, volume=50){
        this.brandTv = brand;
        this.channelTv = channel;
        this.volumeTv = volume;
    }

    increaseVolume () {
        this.volumeTv += 1;
    }

    decreaseVolume () {
        this.volumeTv -= 1;
    }
}

const lgTV = new Tv("LG", 3, 20);
lgTV.increaseVolume()
console.log(lgTV.volumeTv);


// Part II
// Create a subclass  Smart TV of TV
// It overrides the method increase, so it increase the volume by 10 and not by 1
// Add a attribute of Netflix that should be equal to true by default

class SmartTv extends Tv {
    constructor(brandSmartTv, channelSmartTv, volumeSmartTv, isnetflix = true){
        super(brandSmartTv, channelSmartTv, volumeSmartTv) 
        //super calling constructor of the parent
        this.netflix = isnetflix;
    }

    increaseVolume () {
        this.volumeTv += 10;
    }
}

const samsungSmart = new SmartTv("Samsung", 12, 70)
samsungSmart.increaseVolume()
console.log(samsungSmart.volumeTv);
