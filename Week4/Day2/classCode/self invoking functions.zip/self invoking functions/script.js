// Function declaration


makeChocolate(100, 10);

function makeChocolate(gramCacao, gramSugar){
    const totalGram = gramCacao + gramSugar;
    console.log(totalGram);
    return totalGram;
}

makeChocolate(100, 10);


// function expression and arrow function
const makeChocolate = (gramCacao, gramSugar) => {
    const totalGram = gramCacao + gramSugar;
    console.log(totalGram);
    return totalGram;
}

makeChocolate(100, 10);

//self invoking function

// (function funcName (){

// })()

(function makeChocolate (gramCacao, gramSugar){
    const totalGram = gramCacao + gramSugar;
})(100,10)

makeChocolate(10,100) //undefined


//if we want to reuse the returned value

const result = (function makeChocolate (gramCacao, gramSugar){
    const totalGram = gramCacao + gramSugar;
    // console.log(totalGram);
    return totalGram;
})(100,10)


//self invoking function
(function (username){
    const nav = document.getElementById("nav");
    nav.textContent = "Hello " + username;
})("John")

((username) => document.getElementById("nav").textContent = "Hello " + username)("John")


// Arrow function more readable
// Array.forEach((element) => ) 
// Array.forEach(function (element){} )