function makeCake (typeOfCake){ //2.
    const grbutter = 30;
    
    function addChocolate (typeOfChocolate){ //4.
        const grchocolate = 100;
        console.log(`Im making a ${typeOfCake} cake with ${grbutter+grchocolate} grams
        and ${typeOfChocolate} chocolate`);
    }

    addChocolate("black"); //3

    // console.log(typeOfChocolate); //undefined
}

makeCake("chocolate cake") //1.

// addChocolate() //undefined

// ---------------------
///other possibility


// function makeCake (typeOfCake){ //2.
//     const grbutter = 30;
//     addChocolate("black", grbutter);
// }

// function addChocolate (typeOfChocolate, butter){ //4.
//     const grchocolate = 100;
//     console.log(`Im making a ${typeOfCake} cake with ${butter+grchocolate} grams
//     and ${typeOfChocolate} chocolate`);
// }



