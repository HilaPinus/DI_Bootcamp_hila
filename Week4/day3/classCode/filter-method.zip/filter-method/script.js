const numbers = [2, 10, 35, 15, 6];

//WITHOUT FOR EACH
// create a new array with the elements bigger or equal than 10
function addNumber(){
    const biggerThanTen = [];
    for(let num of numbers){
        if(num >= 10){
            biggerThanTen.push(num)
        } else {
            continue;
        }
    }
    console.log(biggerThanTen);
}

addNumber()

// create a new array with the elements bigger or equal than 10
const numBiggerThanTen = numbers.filter((element) => element>= 10);
console.log(numBiggerThanTen);
// [10, 35, 15]

// 1st loop
// element = 2
// element>= 10 - false - skip

// 2nd loop
// element = 10
// element>= 10 - true - add the element to the new array

// 3rd loop
// element = 35
// element>= 10 - true - add the element to the new array

const students = [ 
    {name: 'Rich', score: 33}, 
    {name: 'Peter', score: 55}, 
    {name: 'John', score: 75} 
];

// create an array with the element where the score is bigger than 50

const bestStudents = students.filter((element)=>element.score>50);
console.log(bestStudents);

const bestName = bestStudents.map((element) => element.name)
console.log(bestName);

// 1st loop
// score: 33 -> skip

// 2nd loop
// score: 55 -> {name: 'Peter', score: 55}

//CHAINING
const bestStudentsTwo = students
                    .filter((element)=>element.score>50) //RETURNS AN ARRAY OF OBJECT
                    .map((element) => element.name) //RETURN AN ARRAY OF NAMW
                    .forEach((element) => console.log(element)) //FOR EACH LOOPS THROUGH THE ARRAY OF NAMES

//if the method returns an array you can chain it

// Array.forEach((element) => )
// for each doesnt return an array so we cannot chain it

const strings = ["hello", "great", "Hey"];

// create an array containing elements that start with the letter h
const wordStartWithH = strings.filter((element) => element[0].toLowerCase() === "h")
console.log(wordStartWithH);