const famousPeople = [
    {
        name: "Angelina Jolie",
        job: "actor",
        age: 80
    },
    {
        name: "Georges Clooney",
        job: "actor",
        age: 2
    },
    {
        name: "Paris Hilton",
        job: "actor",
        age: 5
    },
    {
        name: "Kayne West",
        job: "singer",
        age: 16
    },
    {
        name: "Britney Spears",
        job: "singer",
        age: 100
    }
]




// 1. Using the array above, use the map method, to create 
// a new array that contains only the name of the people

const famousPeopleName = famousPeople.map((element) => element["name"]);
const famousPeopleNameTwo = famousPeople.map((element) => element.name);
console.log(famousPeopleName);

// const getName = (element) => element.name;

// function getName (element) {
//     return element.name
// }

// const famousPeopleNameTwo = famousPeople.map(getName);
// console.log(famousPeopleNameTwo);

// 2. Use the map method, to create a new array, 
// that contains objects, each object contains the name of the actor, and it's job

const nameAndJob = famousPeople.map((element) => {
    const peopleObj = {
        chocolate : element["name"], 
        vanilla : element["job"]
    };
    // const peopleObj = {
    //     name:element.name, 
    //     job:element.job
    // }
    return peopleObj;
})


const nameAndJobTwo = famousPeople.map((element) => ({username : element.name, userjob : element.job}))
console.log("nameAndJobTwo", nameAndJobTwo);

nameAndJobTwo.forEach((element) => console.log(element.username))


//in the map method, whatever is returned, is pushed to the array




// BONUS: Using the array you get from question2, use the for each method, to add the names and the job of the actors on the DOM (in a paragraph, appended to a div with an id "container")


const newArray = [
    {
        chocolate: "Angelina Jolie",
        vanilla: "actor",
    },
    {
        chocolate: "Georges Clooney",
        vanilla: "actor",
    },
    {
        chocolate: "Paris Hilton",
        vanilla: "actor",
    },
    {
        chocolate: "Kayne West",
        vanilla: "singer",
    },
    {
        chocolate: "Britney Spears",
        vanilla: "singer",
    }
]

const studentsFootball = [
    {name: 'Rich', score: 33}, 
    {name: 'Peter', score: 55}
];

const studentsNew = studentsFootball.map((element) => ({name: element.name, score: element.score, isAboveAverage: element.score>50 ? true:false}))
console.log(studentsNew);

//the same without ternary operator
const studentsNewTwo = studentsFootball.map((element) => ({name: element.name, score: element.score, isAboveAverage: element.score>50}))
